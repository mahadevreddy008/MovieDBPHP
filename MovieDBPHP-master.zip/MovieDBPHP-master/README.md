Movie Database
===================

This is a movie database site created in PHP using mysql(i).

The user is able to add a movie, remove a movie, and give it a rating. It also provides a way to sort/search for
a movie accoring to the first letter of the movie or the director.